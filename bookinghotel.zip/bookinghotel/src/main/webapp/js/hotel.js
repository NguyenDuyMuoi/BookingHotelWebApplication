var size = 8;
async function loadKhachSanIndex(page, tenloai, idloai) {
    document.getElementById("tenloaiks").innerHTML = tenloai
    var url = 'http://localhost:8080/api/hotel/public/findAll-page?page=' + page + '&size=' + size + '&sort=id,desc';
    if(idloai != null){
        url += '&idCategory='+idloai
    }
    const response = await fetch(url, {
        method: 'GET'
    });
    var result = await response.json();
    console.log(result)
    var list = result.content;
    var totalPage = result.totalPages;

    var main = '';
    for (i = 0; i < list.length; i++) {
        var st = '';
        for(j=0; j<list[i].star; j++){
            st += `<i class="fa fa-star votesao"></i>`
        }
        if(list[i].star == 0){st = `<i class="fa fa-star votesao"></i>`}
        main += `<div class="col-sm-3">
                    <div class="single-ks">
                        <a href="khach-san?id=${list[i].id}" class="aks-index">
                            <img src="${list[i].image}" class="imgks-index">
                            <div class="contentks-index">
                                <span class="ksname-index">${list[i].name}</span>
                                <div class="d-flex listsao">
                                    ${st}
                                    <span class="sldanhgia">(${list[i].numRating})</span>
                                </div>
                                <span class="giatienks">${formatmoney(list[i].avgPrice)}</span>
                                <span class="chuabgthue">Chưa bao gồm thuế và phí</span>
                            </div>
                        </a>
                    </div>
                </div>`
    }
    document.getElementById("listkhachsan").innerHTML = main
    var mainpage = ''
    for (i = 1; i <= totalPage; i++) {
        mainpage += `<li onclick="loadKhachSan(${(Number(i) - 1)})" class="page-item"><a class="page-link" href="#listsp">${i}</a></li>`
    }
    document.getElementById("pageable").innerHTML = mainpage
}


async function loadDaySelect(){
    var main = '';
    var curdate = new Date()
    for(i=1; i< 11; i++){
        var dateObj = new Date();
        dateObj.setDate(curdate.getDate() + i);

        let month = dateObj.getUTCMonth() + 1;
        let day = dateObj.getUTCDate();
        let year = dateObj.getUTCFullYear();
        newdate = day + "/" + month + "/" + year;

        main += `<option value="${i}">${i} Ngày - ${newdate}</option>`
    }
    document.getElementById("songay").innerHTML = main;
}



async function loadAHotel() {
    var uls = new URL(document.URL)
    var id = uls.searchParams.get("id");
    var fromdate = uls.searchParams.get("fromdate");
    var songay = uls.searchParams.get("songay");
    if(fromdate != null && songay != null){
        document.getElementById("fromdate").value = fromdate
        document.getElementById("songay").value = songay
    }
    if (id != null) {
        var url = 'http://localhost:8080/api/hotel/public/findById?id=' + id;
        const response = await fetch(url, {
            method: 'GET'
        });
        var result = await response.json();
        document.getElementById("tenkhachsan").innerHTML = result.name
        document.getElementById("mota-ks").innerHTML = result.description
        document.getElementById("giaphongngay").innerHTML = formatmoney(result.avgPrice)

        if(result.linkMap != null){
            document.getElementById("mapgg").innerHTML = result.linkMap
        }
        var st = '';
        for(j=0; j<result.star; j++){
            st += `<i class="fa fa-star votesao"></i>`
        }
        if(result.star == 0){st = `<i class="fa fa-star votesao"></i>`}
        document.getElementById("list-star").innerHTML = st
        var main = '<div class="carousel-inner carousel-inner-index">';
        main += `<div class="carousel-item active">
                <img src="${result.image}" class="d-block w-100 imgbanner-detail" alt="...">
            </div>`
        var list = result.hotelImages
        for (i = 0; i < list.length; i++) {
            main += `<div class="carousel-item">
                <img src="${list[i].image}" class="d-block w-100 imgbanner-detail" alt="...">
            </div>`
        }
        main += `</div>`
        document.getElementById("carouselindex").innerHTML = main

        var main = ''
        for (i = 0; i < result.hotelUtilities.length; i++) {
            main += `<tr>
                        <td><i class="${result.hotelUtilities[i].utilities.icon} icontienich"></i></td>
                        <td class="tdtienich">${result.hotelUtilities[i].utilities.name}</td>
                    </tr>`
        }
        document.getElementById("listtienich").innerHTML = main
    }
}



async function loadAvailableHotels(page) {
    const fromDate = document.getElementById("fromdate").value;
    const numDays = document.getElementById("songay").value;
    const categoryIds = Array.from(document.querySelectorAll('input[name="danhmucsearch"]:checked'))
        .map(checkbox => checkbox.value)
        .join(",");

    const url = `http://localhost:8080/api/hotel/public/available?fromDate=${fromDate}&numDays=${numDays}&categoryIds=${categoryIds}&size=${size}&page=${page}`;
    const response = await fetch(url);
    var result = await response.json();
    console.log(result)
    var list = result.content;
    var totalPage = result.totalPages;
    document.getElementById("soks").innerHTML = result.totalElements
    var main = '';
    for (i = 0; i < list.length; i++) {
        var st = '';
        for(j=0; j<list[i].star; j++){
            st += `<i class="fa fa-star votesao"></i>`
        }
        if(list[i].star == 0){st = `<i class="fa fa-star votesao"></i>`}
        main += `<div class="col-sm-3">
                    <div class="single-ks">
                        <a onclick="chuyenTrangChiTiet(${list[i].id}, '${fromDate}', ${numDays})" href="#" class="aks-index">
                            <img src="${list[i].image}" class="imgks-index">
                            <div class="contentks-index">
                                <span class="ksname-index">${list[i].name}</span>
                                <div class="d-flex listsao">
                                    ${st}
                                    <span class="sldanhgia">(${list[i].numRating})</span>
                                </div>
                                <span class="giatienks">${formatmoney(list[i].avgPrice)}</span>
                                <span class="chuabgthue">Chưa bao gồm thuế và phí</span>
                            </div>
                        </a>
                    </div>
                </div>`
    }
    document.getElementById("listkhachsan").innerHTML = main
    var mainpage = ''
    for (i = 1; i <= totalPage; i++) {
        mainpage += `<li onclick="loadKhachSan(${(Number(i) - 1)})" class="page-item"><a class="page-link" href="#listsp">${i}</a></li>`
    }
    document.getElementById("pageable").innerHTML = mainpage
}


function chuyenTrangChiTiet(idks, from, songay){
    window.location.href = `khach-san?id=${idks}&fromdate=${from}&songay=${songay}`
}