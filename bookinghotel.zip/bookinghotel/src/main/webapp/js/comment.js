var star = 5;
function loadStar(val) {
    star = val + 1;
    var listS = document.getElementById("liststar").getElementsByClassName("fa-star");
    for (i = 0; i < listS.length; i++) {
        listS[i].classList.remove('checkedstar');
    }
    for (i = 0; i < listS.length; i++) {
        if (i <= val) {
            listS[i].classList.add('checkedstar');
        }
    }
}


async function loadComment() {
    var uls = new URL(document.URL)
    var id = uls.searchParams.get("id");
    if (id != null) {
        var url = 'http://localhost:8080/api/comment/public/find-by-hotel?hotelId=' + id;
        const response = await fetch(url, {
        });
        var list = await response.json();
        var main = ''
        for (i = 0; i < list.length; i++) {
            main += `<div class="singledanhgia">
                        <div class="head-comment d-flex">
                            <span class="hotendg">${list[i].fullName}</span>
                            <span class="sosaobl">${list[i].star} / 5</span>
                            <span class="ngaybl">${list[i].createdTime}, ${list[i].createdDate}</span>

                        </div>
                        <span class="noidungdg">${list[i].content}</span>
                    </div>`
        }
        document.getElementById("listdanhgia").innerHTML = main
    }
}


async function saveComment() {
    var uls = new URL(document.URL)
    var id = uls.searchParams.get("id");
    var url = 'http://localhost:8080/api/comment/public/create';
    var noidungbl = document.getElementById("noidungbl").value
    var comment = {
        "star": star,
        "content": noidungbl,
        "fullName": document.getElementById("hotenbl").value,
        "email": document.getElementById("sdtbl").value,
        "phone": document.getElementById("emailbl").value,
        "hotel": {
            "id": id
        }
    }
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(comment)
    });
    if (response.status < 300) {
        toastr.success("Đã đăng bình luận của bạn")
        loadComment();
    } else {
        toastr.error("Thất bại!");
    }
}