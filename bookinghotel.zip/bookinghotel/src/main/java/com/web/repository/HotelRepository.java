package com.web.repository;

import com.web.entity.Hotel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface HotelRepository extends JpaRepository<Hotel, Long> {

    @Query("select h from Hotel h where h.category.id = ?1")
    Page<Hotel> findByCategory(Long idCategory, Pageable pageable);

    @Query("SELECT DISTINCT h FROM Hotel h " +
            "JOIN h.rooms r " +
            "LEFT JOIN BookingRoom br ON r.id = br.room.id " +
            "LEFT JOIN br.booking b " +
            "WHERE (:categoryIds IS NULL OR h.category.id IN :categoryIds) " +
            "AND (br.id IS NULL OR NOT (br.fromDate < :toDate AND br.toDate > :fromDate))")
    Page<Hotel> findAvailableHotels(@Param("fromDate") java.util.Date fromDate,
                                    @Param("toDate") java.util.Date toDate,
                                    @Param("categoryIds") List<Long> categoryIds,
                                    Pageable pageable);
}
