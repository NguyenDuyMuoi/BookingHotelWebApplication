package com.web.api;

import com.web.dto.PaymentDto;
import com.web.dto.ResponsePayment;
import com.web.entity.Room;
import com.web.entity.Voucher;
import com.web.exception.MessageException;
import com.web.repository.RoomRepository;
import com.web.service.VoucherService;
import com.web.vnpay.VNPayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/vnpay")
@CrossOrigin
public class VnpayApi {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private VoucherService voucherService;

    @Autowired
    private VNPayService vnPayService;

    @PostMapping("/urlpayment")
    public ResponsePayment getUrlPayment(@RequestBody PaymentDto paymentDto){
        Double totalAmount = 0D;
        List<Room> list = roomRepository.findAllById(paymentDto.getListRoomId());
        for(Room p : list){
            totalAmount += p.getPrice() * paymentDto.getNumDate();
        }
        if(paymentDto.getCodeVoucher() != null){
            Optional<Voucher> voucher = voucherService.findByCode(paymentDto.getCodeVoucher(), totalAmount);
            if(voucher.isPresent()){
                totalAmount = totalAmount - voucher.get().getDiscount();
            }
        }
        String orderId = String.valueOf(System.currentTimeMillis());
        String vnpayUrl = vnPayService.createOrder(totalAmount.intValue(), orderId, paymentDto.getReturnUrl());
        ResponsePayment responsePayment = new ResponsePayment(vnpayUrl,orderId,null);
        return responsePayment;
    }
}
