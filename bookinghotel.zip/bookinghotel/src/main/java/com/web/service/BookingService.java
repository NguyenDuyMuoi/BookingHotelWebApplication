package com.web.service;

import com.web.dto.BookingDto;
import com.web.entity.*;
import com.web.enums.PayStatus;
import com.web.exception.MessageException;
import com.web.repository.*;
import com.web.utils.MailService;
import com.web.utils.UserUtils;
import com.web.vnpay.VNPayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.sql.Time;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private BookingRoomRepository bookingRoomRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private UserUtils userUtils;

    @Autowired
    private MailService mailService;

    @Autowired
    private VNPayService vnPayService;

    @Autowired
    private VoucherService voucherService;

    @Autowired
    private HistoryPayRepository historyPayRepository;

    public void create(BookingDto bookingDto) throws Exception {
        if (historyPayRepository.findByOrderIdAndRequestId(bookingDto.getVnpOrderInfo(), bookingDto.getVnpOrderInfo())
                .isPresent()) {
            throw new MessageException("Đơn hàng đã được thanh toán");
        }
        int paymentStatus = vnPayService.orderReturnByUrl(bookingDto.getUrlVnpay());
        if (paymentStatus != 1) {
            throw new MessageException("Thanh toán thất bại");
        }

        List<Room> rooms = getListRoom(bookingDto.getListRoomId());
        Double amount = 0D;
        for (Room r : rooms) {
            amount += r.getPrice() * bookingDto.getNumDate();
        }

        Long longTo = bookingDto.getFromDate().getTime() + (1000L * 60L * 60L * 24L * (bookingDto.getNumDate()));
        Date toDate = new Date(longTo);
        User u = userUtils.getUserWithAuthority();
        Booking booking = new Booking();
        booking.setCreatedDate(new Date(System.currentTimeMillis()));
        booking.setCreatedTime(new Time(System.currentTimeMillis()));
        booking.setUser(u);
        booking.setPayStatus(PayStatus.PAID);
        booking.setFullname(bookingDto.getFullname());
        booking.setPhone(bookingDto.getPhone());
        booking.setCccd(bookingDto.getCccd());
        booking.setNote(bookingDto.getNote());
        booking.setFromDate(bookingDto.getFromDate());
        booking.setToDate(toDate);
        booking.setNumDate(bookingDto.getNumDate());
        booking.setDiscount(0D);
        if (bookingDto.getVoucherCode() != null) {
            if (!bookingDto.getVoucherCode().equals("null") && !bookingDto.getVoucherCode().equals("")) {
                System.out.println("voucher use === " + bookingDto.getVoucherCode());
                Optional<Voucher> voucher = voucherService.findByCode(bookingDto.getVoucherCode(), amount);
                if (voucher.isPresent()) {
                    amount = amount - voucher.get().getDiscount();
                    booking.setDiscount(voucher.get().getDiscount());
                }
            }
        }
        booking.setAmountRoom(amount);
        Booking result = bookingRepository.save(booking);

        mailService.sendEmail(u.getEmail(), "Đặt lịch thành công",
                "Cảm ơn bạn đã tin tưởng dịch vụ của chúng tôi<br>Tổng tiền phải thanh toán:" + booking.getAmountRoom()
                        +
                        "<br>ngày đặt:" + booking.getCreatedDate() + ", " + booking.getCreatedTime(),
                false, true);
        for (Room r : rooms) {
            BookingRoom bookingRoom = new BookingRoom();
            bookingRoom.setBooking(result);
            bookingRoom.setRoom(r);
            bookingRoom.setFromDate(bookingDto.getFromDate());
            bookingRoom.setNumDay(bookingDto.getNumDate());
            bookingRoom.setPrice(r.getPrice());
            bookingRoom.setToDate(toDate);
            bookingRoomRepository.save(bookingRoom);
        }

        HistoryPay historyPay = new HistoryPay();
        historyPay.setRequestId(bookingDto.getVnpOrderInfo());
        historyPay.setOrderId(bookingDto.getVnpOrderInfo());
        historyPay.setCreatedTime(new Time(System.currentTimeMillis()));
        historyPay.setCreatedDate(new Date(System.currentTimeMillis()));
        historyPay.setTotalAmount(amount);
        historyPayRepository.save(historyPay);
    }

    public List<Room> getListRoom(List<Long> listRoomId) {
        return roomRepository.findAllById(listRoomId);
    }

    public List<Booking> allBooking(Date from, Date to) {
        List<Booking> list = null;
        if (from == null || to == null) {
            from = Date.valueOf("2000-01-01");
            to = Date.valueOf("2100-01-01");
        }
        list = bookingRepository.allBooking(from, to);
        return list;
    }

    public List<Booking> myBooking() {
        return bookingRepository.myBooking(userUtils.getUserWithAuthority().getId());
    }
}
