package com.web.service;
import com.web.entity.Comment;
import com.web.entity.Hotel;
import com.web.repository.CategoryRepository;
import com.web.repository.CommentRepository;
import com.web.repository.HotelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private HotelRepository hotelRepository;

    public Comment save(Comment comment){
        comment.setCreatedTime(new Time(System.currentTimeMillis()));
        comment.setCreatedDate(new Date(System.currentTimeMillis()));
        Comment result = commentRepository.save(comment);

        Long count = commentRepository.countCommentByHotel(comment.getHotel().getId());
        Float totalStar = commentRepository.sumStarCommentByHotel(comment.getHotel().getId());
        Hotel hotel = hotelRepository.findById(comment.getHotel().getId()).get();
        Integer v = Integer.valueOf((int) (totalStar / count));

        hotel.setStar(v.floatValue());
        hotelRepository.save(hotel);
        return result;
    }

    public List<Comment> findByHotel (Long hotelId){
        List<Comment> result = commentRepository.findByHotel(hotelId);
        return result;
    }

}
