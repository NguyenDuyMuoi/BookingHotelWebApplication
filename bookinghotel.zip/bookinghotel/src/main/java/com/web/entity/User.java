package com.web.entity;

import com.web.enums.Role;
import com.web.enums.UserType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

@Entity
@Table(name = "users")
@Getter
@Setter
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    private String email;

    private String password;

    private Boolean actived;

    private String phone;

    private String fullName;

    private String address;

    private String activationKey;

    private Date createdDate;

    private UserType userType;

    @Enumerated(EnumType.STRING)
    private Role role;
}
